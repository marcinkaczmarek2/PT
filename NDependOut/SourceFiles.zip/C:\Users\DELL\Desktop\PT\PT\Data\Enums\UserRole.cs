﻿namespace Data.Enums
{
    public enum UserRole
    {
        Admin,
        Reader,
        Guest
    }
}
