﻿

namespace Data.Enums
{
    public enum BookGenre
    {
        Fantasy,
        ScienceFiction,
        Romance,
        Mystery,
        Thriller,
        Horror,
        Biography,
        History,
        Science,
        Philosophy,
        Poetry,
        Drama,
        Adventure,
        SelfImprovement,
        Business,
        Health,
        Religion,
        Travel,
        Art,
        Comic,
        Children,
        YoungAdult
    }
}
